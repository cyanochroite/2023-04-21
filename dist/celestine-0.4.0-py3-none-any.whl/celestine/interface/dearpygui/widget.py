class Widget():
    pass
