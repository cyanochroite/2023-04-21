from .widget import Widget


class Label(Widget):
    pass
