"""et Estonian eesti"""
LANGUAGE = "ELil on 24 ametlikku keelt: bulgaaria, eesti, hispaania, \
hollandi, horvaadi, iiri, inglise, itaalia, kreeka, leedu, läti, \
malta, poola, portugali, prantsuse, rootsi, rumeenia, saksa, slovaki, \
sloveeni, soome, taani, tšehhi ja ungari keel."
LANGUAGE_NAME_ENGLISH = "Estonian"
LANGUAGE_NAME_NATIVE = "eesti"
LANGUAGE_TAG_AZURE = "et"
LANGUAGE_TAG_ISO = "et"
