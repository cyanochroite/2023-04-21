"""sv Swedish svenska"""
LANGUAGE = "EU har 24 officiella språk: Bulgariska, danska, engelska, \
estniska, finska, franska, grekiska, iriska, italienska, kroatiska, \
lettiska, litauiska, maltesiska, nederländska, polska, portugisiska, \
rumänska, slovakiska, slovenska, spanska, svenska, tjeckiska, \
tyska och ungerska."
LANGUAGE_NAME_ENGLISH = "Swedish"
LANGUAGE_NAME_NATIVE = "svenska"
LANGUAGE_TAG_AZURE = "sv"
LANGUAGE_TAG_ISO = "sv"
