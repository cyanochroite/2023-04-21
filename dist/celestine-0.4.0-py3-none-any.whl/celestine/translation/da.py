"""da Danish dansk"""
LANGUAGE = "EU har 24 officielle sprog: bulgarsk, dansk, engelsk, \
estisk, finsk, fransk, græsk, irsk, italiensk, kroatisk, lettisk, \
litauisk, maltesisk, nederlandsk, polsk, portugisisk, rumænsk, \
slovakisk, slovensk, spansk, svensk, tjekkisk, tysk og ungarsk."
LANGUAGE_NAME_ENGLISH = "Danish"
LANGUAGE_NAME_NATIVE = "dansk"
LANGUAGE_TAG_AZURE = "da"
LANGUAGE_TAG_ISO = "da"
