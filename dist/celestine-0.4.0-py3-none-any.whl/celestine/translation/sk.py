"""sk Slovak slovenčina"""
LANGUAGE = "EÚ má 24 úradných jazykov, ktorými sú: angličtina, \
bulharčina, čeština, dánčina, estónčina, fínčina, francúzština, \
gréčtina, holandčina, chorvátčina, írčina, litovčina, lotyština, \
maďarčina, maltčina, nemčina, poľština, portugalčina, rumunčina, \
slovenčina, slovinčina, španielčina, švédčina a taliančina."
LANGUAGE_NAME_ENGLISH = "Slovak"
LANGUAGE_NAME_NATIVE = "slovenčina"
LANGUAGE_TAG_AZURE = "sk"
LANGUAGE_TAG_ISO = "sk"
