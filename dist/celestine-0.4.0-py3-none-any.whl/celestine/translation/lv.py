"""lv Latvian latviešu"""
LANGUAGE = "ES ir 24 oficiālās valodas: angļu, bulgāru, čehu, dāņu, \
franču, grieķu, horvātu, igauņu, itāļu, īru, latviešu, lietuviešu, \
maltiešu, nīderlandiešu, poļu, portugāļu, rumāņu, slovāku, slovēņu, \
somu, spāņu, ungāru, vācu un zviedru."
LANGUAGE_NAME_ENGLISH = "Latvian"
LANGUAGE_NAME_NATIVE = "latviešu"
LANGUAGE_TAG_AZURE = "lv"
LANGUAGE_TAG_ISO = "lv"
