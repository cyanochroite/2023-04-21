"""pt Portuguese português"""
LANGUAGE = "A UE tem 24 línguas oficiais: alemão, búlgaro, checo, \
croata, dinamarquês, eslovaco, esloveno, espanhol, estónio, finlandês, \
francês, grego, húngaro, inglês, irlandês, italiano, letão, lituano, \
maltês, neerlandês, polaco, português, romeno e sueco."
LANGUAGE_NAME_ENGLISH = "Portuguese"
LANGUAGE_NAME_NATIVE = "português"
LANGUAGE_TAG_AZURE = "pt-PT"
LANGUAGE_TAG_ISO = "pt"
