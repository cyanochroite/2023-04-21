"""pl Polish polski"""
LANGUAGE = "W UE obowiązują 24 języki urzędowe: angielski, bułgarski, \
chorwacki, czeski, duński, estoński, fiński, francuski, grecki, \
hiszpański, irlandzki, litewski, łotewski, maltański, niderlandzki, \
niemiecki, polski, portugalski, rumuński, słowacki, słoweński, \
szwedzki, węgierski i włoski."
LANGUAGE_NAME_ENGLISH = "Polish"
LANGUAGE_NAME_NATIVE = "polski"
LANGUAGE_TAG_AZURE = "pl"
LANGUAGE_TAG_ISO = "pl"
