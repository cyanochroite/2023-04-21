"""es Spanish español"""
LANGUAGE = "La UE tiene 24 lenguas oficiales: el alemán, el búlgaro, \
el checo, el croata, el danés, el eslovaco, el esloveno, el español, \
el estonio, el finés, el francés, el griego, el húngaro, el inglés, \
el irlandés, el italiano, el letón, el lituano, el maltés, \
el neerlandés, el polaco, el portugués, el rumano y el sueco."
LANGUAGE_NAME_ENGLISH = "Spanish"
LANGUAGE_NAME_NATIVE = "español"
LANGUAGE_TAG_AZURE = "es"
LANGUAGE_TAG_ISO = "es"
