"""nl Dutch Nederlands"""
LANGUAGE = "De EU heeft 24 officiële talen: Bulgaars, Deens, Duits, \
Engels, Ests, Fins, Frans, Grieks, Hongaars, Iers, Italiaans, \
Kroatisch, Lets, Litouws, Maltees, Nederlands, Pools, Portugees, \
Roemeens, Sloveens, Slowaaks, Spaans, Tsjechisch en Zweeds."
LANGUAGE_NAME_ENGLISH = "Dutch"
LANGUAGE_NAME_NATIVE = "Nederlands"
LANGUAGE_TAG_AZURE = "nl"
LANGUAGE_TAG_ISO = "nl"
