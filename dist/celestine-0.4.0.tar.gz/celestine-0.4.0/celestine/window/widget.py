
class Widget():
    pass
