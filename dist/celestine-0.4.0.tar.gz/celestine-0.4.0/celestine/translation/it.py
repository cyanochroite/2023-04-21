"""it Italian italiano"""
LANGUAGE = "L'UE ha 24 lingue ufficiali: bulgaro, ceco, croato, \
danese, estone, finlandese, francese, greco, inglese, irlandese, \
italiano, lettone, lituano, maltese, neerlandese, polacco, portoghese, \
rumeno, slovacco, sloveno, spagnolo, tedesco, svedese e ungherese."
LANGUAGE_NAME_ENGLISH = "Italian"
LANGUAGE_NAME_NATIVE = "italiano"
LANGUAGE_TAG_AZURE = "it"
LANGUAGE_TAG_ISO = "it"
