"""hu Hungarian magyar"""
LANGUAGE = "Az Európai Uniónak 24 hivatalos nyelve van, \
melyek a következők: angol, bolgár, cseh, dán, észt, finn, francia, \
görög, holland, horvát, ír, lengyel, lett, litván, magyar, máltai, \
német, olasz, portugál, román, spanyol, svéd, szlovák és szlovén."
LANGUAGE_NAME_ENGLISH = "Hungarian"
LANGUAGE_NAME_NATIVE = "magyar"
LANGUAGE_TAG_AZURE = "hu"
LANGUAGE_TAG_ISO = "hu"
