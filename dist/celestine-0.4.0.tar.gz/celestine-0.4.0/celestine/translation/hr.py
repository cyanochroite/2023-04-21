"""hr Croatian hrvatski"""
LANGUAGE = "EU ima 24 službena jezika: bugarski, češki, danski, \
engleski, estonski, finski, francuski, grčki, hrvatski, irski, \
latvijski, litavski, mađarski, malteški, nizozemski, njemački, \
poljski, portugalski, rumunjski, slovački, slovenski, španjolski, \
švedski i talijanski."
LANGUAGE_NAME_ENGLISH = "Croatian"
LANGUAGE_NAME_NATIVE = "hrvatski"
LANGUAGE_TAG_AZURE = "hr"
LANGUAGE_TAG_ISO = "hr"
