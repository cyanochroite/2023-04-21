"""fr French français"""
LANGUAGE = "L’UE compte 24 langues officielles: allemand, anglais, \
bulgare, croate, danois, espagnol, estonien, finnois, français, grec, \
hongrois, irlandais, italien, letton, lituanien, maltais, néerlandais, \
polonais, portugais, roumain, slovaque, slovène, suédois et tchèque."
LANGUAGE_NAME_ENGLISH = "French"
LANGUAGE_NAME_NATIVE = "français"
LANGUAGE_TAG_AZURE = "fr"
LANGUAGE_TAG_ISO = "fr"
