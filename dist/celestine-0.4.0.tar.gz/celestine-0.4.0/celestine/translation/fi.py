"""fi Finnish suomi"""
LANGUAGE = "EU: ssa on 24 virallista kieltä: bulgaria, englanti, \
espanja, hollanti, iiri, italia, kreikka, kroaatti, latvia, liettua, \
malta, portugali, puola, ranska, romania, ruotsi, saksa, slovakki, \
sloveeni, suomi, tanska, tšekki, unkari ja viro."
LANGUAGE_NAME_ENGLISH = "Finnish"
LANGUAGE_NAME_NATIVE = "suomi"
LANGUAGE_TAG_AZURE = "fi"
LANGUAGE_TAG_ISO = "fi"
