"""mt Maltese Malti"""
LANGUAGE = "L-UE għandha 24 lingwa uffiċjali: Il-Bulgaru, iċ-Ċek, \
id-Daniż, l-Estonjan, il-Finlandiż, il-Franċiż, il-Ġermaniż, il-Grieg, \
l-Ingliż, l-Irlandiż, il-Kroat, il-Latvjan, il-Litwan, il-Malti, \
l-Olandiż, il-Pollakk, il-Portugiż, ir-Rumen, is-Slovakk, is-Sloven, \
l-Ispanjol, it-Taljan, l-Ungeriż u l-Iżvediż."
LANGUAGE_NAME_ENGLISH = "Maltese"
LANGUAGE_NAME_NATIVE = "Malti"
LANGUAGE_TAG_AZURE = "mt"
LANGUAGE_TAG_ISO = "mt"
