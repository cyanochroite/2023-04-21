"""en English English"""
LANGUAGE = "The EU has 24 official languages: Bulgarian, Croatian, \
Czech, Danish, Dutch, English, Estonian, Finnish, French, German, \
Greek, Hungarian, Irish, Italian, Latvian, Lithuanian, Maltese, \
Polish, Portuguese, Romanian, Slovak, Slovenian, Spanish and Swedish."
LANGUAGE_NAME_ENGLISH = "English"
LANGUAGE_NAME_NATIVE = "English"
LANGUAGE_TAG_AZURE = "en"
LANGUAGE_TAG_ISO = "en"
