"""sl Slovenian slovenščina"""
LANGUAGE = "V EU je 24 uradnih jezikov: angleščina, bolgarščina, \
češčina, danščina, estonščina, finščina, francoščina, grščina, \
hrvaščina, irščina, italijanščina, latvijščina, litovščina, \
madžarščina, malteščina, nemščina, nizozemščina, poljščina, \
portugalščina, romunščina, slovaščina, slovenščina, \
španščina in švedščina."
LANGUAGE_NAME_ENGLISH = "Slovenian"
LANGUAGE_NAME_NATIVE = "slovenščina"
LANGUAGE_TAG_AZURE = "sl"
LANGUAGE_TAG_ISO = "sl"
