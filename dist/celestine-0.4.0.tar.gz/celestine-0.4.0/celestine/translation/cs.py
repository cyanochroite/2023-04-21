"""cs Czech čeština"""
LANGUAGE = "EU má 24 úředních jazyků. Jsou jimi: angličtina, \
bulharština, čeština, dánština, estonština, finština, francouzština, \
chorvatština, irština, italština, litevština, lotyština, maďarština, \
maltština, němčina, nizozemština, polština, portugalština, rumunština, \
řečtina, slovenština, slovinština, španělština a švédština."
LANGUAGE_NAME_ENGLISH = "Czech"
LANGUAGE_NAME_NATIVE = "čeština"
LANGUAGE_TAG_AZURE = "cs"
LANGUAGE_TAG_ISO = "cs"
