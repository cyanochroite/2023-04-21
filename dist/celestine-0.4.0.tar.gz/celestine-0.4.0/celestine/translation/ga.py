"""ga Irish Gaeilge"""
LANGUAGE = "Tá 24 theanga oifigiúla san Aontas: Béarla, Bulgáiris, \
Cróitis, Danmhairgis, Eastóinis, Fionlainnis, Fraincis, Gaeilge, \
Gearmáinis, Gréigis, Iodáilis, Laitvis, Liotuáinis, Máltais, \
Ollainnis, Polainnis, Portaingéilis, Rómáinis, Seicis, Slóivéinis, \
Slóvaicis, Spáinnis, Sualainnis agus Ungáiris."
LANGUAGE_NAME_ENGLISH = "Irish"
LANGUAGE_NAME_NATIVE = "Gaeilge"
LANGUAGE_TAG_AZURE = "ga"
LANGUAGE_TAG_ISO = "ga"
