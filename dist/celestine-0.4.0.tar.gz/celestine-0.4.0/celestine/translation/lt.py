"""lt Lithuanian lietuvių"""
LANGUAGE = "ES yra 24 oficialiosios kalbos: airių, anglų, bulgarų, \
čekų, danų, estų, graikų, ispanų, italų, kroatų, latvių, lenkų, \
lietuvių, maltiečių, nyderlandų, portugalų, prancūzų, rumunų, slovakų, \
slovėnų, suomių, švedų, vengrų, vokiečių."
LANGUAGE_NAME_ENGLISH = "Lithuanian"
LANGUAGE_NAME_NATIVE = "lietuvių"
LANGUAGE_TAG_AZURE = "lt"
LANGUAGE_TAG_ISO = "lt"
