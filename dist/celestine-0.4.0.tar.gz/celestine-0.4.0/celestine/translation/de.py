"""de German Deutsch"""
LANGUAGE = "Die EU hat 24 Amtssprachen: Bulgarisch, Dänisch, Deutsch, \
Englisch, Estnisch, Finnisch, Französisch, Griechisch, Irisch, \
Italienisch, Kroatisch, Lettisch, Litauisch, Maltesisch, \
Niederländisch, Polnisch, Portugiesisch, Rumänisch, Schwedisch, \
Slowakisch, Slowenisch, Spanisch, Tschechisch und Ungarisch."
LANGUAGE_NAME_ENGLISH = "German"
LANGUAGE_NAME_NATIVE = "Deutsch"
LANGUAGE_TAG_AZURE = "de"
LANGUAGE_TAG_ISO = "de"
