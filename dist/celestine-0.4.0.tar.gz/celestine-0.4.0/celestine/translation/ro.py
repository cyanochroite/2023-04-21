"""ro Romanian română"""
LANGUAGE = "UE numără 24 de limbi oficiale: bulgară, cehă, croată, \
daneză, engleză, estonă, finlandeză, franceză, germană, greacă, \
irlandeză, italiană, letonă, lituaniană, maghiară, malteză, \
neerlandeză, polonă, portugheză, română, slovacă, slovenă, \
spaniolă și suedeză."
LANGUAGE_NAME_ENGLISH = "Romanian"
LANGUAGE_NAME_NATIVE = "română"
LANGUAGE_TAG_AZURE = "ro"
LANGUAGE_TAG_ISO = "ro"
