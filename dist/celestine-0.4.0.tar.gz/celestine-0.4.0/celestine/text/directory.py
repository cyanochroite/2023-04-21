""""""

APPLICATION = "application"
INTERFACE = "interface"
LANGUAGE = "language"
