"""da Danish dansk"""
APPLICATION_TITLE = "Celestine Billedfremviser"
ARGUMENT_APPLICATION_DESCRIPTION = "Dine programværdier goe her. Yay."
ARGUMENT_APPLICATION_HELP = "Vælg et program, der skal køres."
ARGUMENT_APPLICATION_TITLE = "Ansøgning"
ARGUMENT_CUSTOMIZATION_DESCRIPTION = "\
Celestine vil forsøge at gætte de bedste indstillinger, \
der skal bruges. Du kan anmode om at bruge disse værdier i stedet."
ARGUMENT_CUSTOMIZATION_TITLE = "Tilpasning"
ARGUMENT_HELP_HELP = "Viser denne hjælpeskærm."
ARGUMENT_INFORMATION_DESCRIPTION = "\
Inkludering af disse vil afslutte programmet for at vise information."
ARGUMENT_INFORMATION_TITLE = "Information"
ARGUMENT_INTERFACE_HELP = "Hvilken GUI vil du bruge?"
ARGUMENT_LANGUAGE_HELP = "EU har 24 officielle sprog: bulgarsk, \
kroatisk, tjekkisk, dansk, engelsk, estisk, finsk, fransk, græsk, \
irsk, italiensk, lettisk, litauisk, maltesisk, nederlandsk, polsk, \
portugisisk, rumænsk, slovakisk, slovensk, spansk, svensk, tjekkisk, \
tysk, ungarsk, tjekkisk, tysk og ungarsk."
ARGUMENT_MODIFICATION_DESCRIPTION = "konfigurere flag"
ARGUMENT_MODIFICATION_TITLE = "Modificering"
ARGUMENT_PARSER_ARGUMENT = "argument"
ARGUMENT_PARSER_CHOICE = "ugyldigt valg"
ARGUMENT_PARSER_CHOOSE = "Vælg mellem"
ARGUMENT_PARSER_ERROR = "fejl"
ARGUMENT_PARSER_USAGE = "brug"
ARGUMENT_PYTHON_HELP = "Vælg, hvilken version af Python du bruger."
ARGUMENT_VERSION_HELP = "Viser den aktuelle version."
CURSES_EXIT = "Tryk på ESC-tasten for at afslutte."
DEMO_MAIN_NEXT = "Gå til side to."
DEMO_MAIN_PAST = "Gå til side et."
DEMO_MAIN_TITLE = "Side vigtigste."
DEMO_ONE_NEXT = "Gå til side to."
DEMO_ONE_PAST = "Gå til side hoved."
DEMO_ONE_TITLE = "Side et."
DEMO_TWO_NEXT = "Gå til side hoved."
DEMO_TWO_PAST = "Gå til side et."
DEMO_TWO_TITLE = "Side to."
LANGUAGE = "EU har 24 officielle sprog: bulgarsk, dansk, engelsk, \
estisk, finsk, fransk, græsk, irsk, italiensk, kroatisk, lettisk, \
litauisk, maltesisk, nederlandsk, polsk, portugisisk, rumænsk, \
slovakisk, slovensk, spansk, svensk, tjekkisk, tysk og ungarsk."
LANGUAGE_NAME_ENGLISH = "Danish"
LANGUAGE_NAME_NATIVE = "dansk"
LANGUAGE_TAG_AZURE = "da"
LANGUAGE_TAG_ISO = "da"
TRANSLATOR_FILE_ERROR_OVERFLOW = "Vi løb over."
TRANSLATOR_SESSION_KEY = "\
Din Translator-tjenestenøgle fra Azure-portalen."
TRANSLATOR_SESSION_REGION = "Det område, \
hvor din ressource blev oprettet."
TRANSLATOR_SESSION_URL = "Placeringen af oversættelsestjenesten."
VIEWER_SESSION_DIRECTORY = "En sti til en mappe, \
der indeholder billeder."
